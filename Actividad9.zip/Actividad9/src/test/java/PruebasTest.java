import metodos.Pruebas;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
public class PruebasTest {
    
    @Test//Contar palabras
    public void test1(){
        int esperado = 2;
        int actual = Pruebas.ContadorPalabras("Hola Mundo");
        assertEquals(esperado,actual);
    }
    @Test
    public void test2(){
        int esperado = 6;
        int actual = Pruebas.ContadorPalabras("Hola Obed mi internet es lento");
        assertEquals(esperado,actual);
    }
    @Test
    public void test3(){
        int esperado = 4;
        int actual = Pruebas.ContadorPalabras("Dame medio de tortilla");
        assertEquals(esperado,actual);
    }
    
    @Test //Menor o igual a cero
    public void test4(){
        boolean esperado = false;
        boolean actual = Pruebas.MenorOigualAcero(6);
        assertEquals(esperado,actual);
    }
    @Test 
    public void test5(){
        boolean esperado = true;
        boolean actual = Pruebas.MenorOigualAcero(0);
        assertEquals(esperado,actual);
    }
    @Test
    public void test6(){
        boolean esperado = true;
        boolean actual = Pruebas.MenorOigualAcero(-5);
        assertEquals(esperado,actual);
    }
    
    @Test//Tartamudear
    public void test7(){
        String esperado = "In... In... Internet?";
        String actual = Pruebas.Palabras("Internet");
         assertEquals(esperado,actual);
    }
    @Test
    public void test8(){
        String esperado = "Ho... Ho... Hola?";
        String actual = Pruebas.Palabras("Hola");
         assertEquals(esperado,actual);
    }
    @Test
    public void test9(){
        String esperado = "Ve... Ve... Venancio?";
        String actual = Pruebas.Palabras("Venancio");
         assertEquals(esperado,actual);
    }
    
    @Test//Tazas
    public void test10(){
        int esperado = 495;
        int actual = Pruebas.Tazas(425);
        assertEquals(esperado,actual);
    }
    @Test
    public void test11(){
        int esperado = 26;
        int actual = Pruebas.Tazas(23);
        assertEquals(esperado,actual);
    }
     @Test
    public void test12(){
        int esperado = 67;
        int actual = Pruebas.Tazas(58);
        assertEquals(esperado,actual);
    }
}
