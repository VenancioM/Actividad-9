package metodos;
import java.util.StringTokenizer;
public class Pruebas {
    
    public static boolean MenorOigualAcero(int a){
        if(a == 0 || a < 0){
            return true;
        }else{
            return false;
        }
    }
    
    public static String Palabras(String U){
        String Palabra = U;
        String Extraer = Palabra.substring(0,2);
        String Union = Extraer+"... "+Extraer+"... "+Palabra+"?";
        return Union;
    }
    
    public static int Tazas(int O){
        int Promocion = 6;
        int D = O / Promocion;
        int T = D + O;
        return T;
    }
    
    public static int ContadorPalabras(String u){
        String Frase = u;
        StringTokenizer st = new StringTokenizer(Frase);
        return st.countTokens();
    }
    
    
}
